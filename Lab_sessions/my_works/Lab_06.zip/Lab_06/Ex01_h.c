#include <stdio.h>

int main() {
    int i = 3; // initialization.
    while(i < 100) { // condition.
        printf("%d\n", i);
        i += 3; // modify value.
    }
}