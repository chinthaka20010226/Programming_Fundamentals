#include <stdio.h>

int main() {
    int i = 3;
    while(i < 100) {
        printf("%d\n", i);
        i += 2;
    }
}