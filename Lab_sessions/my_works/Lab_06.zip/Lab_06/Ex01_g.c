#include <stdio.h>

int main() {
    int i = 2; // initialization.
    while(i < 100) { // condition.
        printf("%d\n", i);
        i += 2; // update value.
    }
}