#include <stdio.h>

int main() {
    int i = 1; // initialization.
    while(i <= 52) { // condition.
        printf("%d\n", i);
        i += 3; // increment value by 3.
    }
}