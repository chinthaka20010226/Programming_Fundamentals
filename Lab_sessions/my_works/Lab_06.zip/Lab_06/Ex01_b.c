#include <stdio.h>

int main() {
    int i = 10; // initialization.
    while(i > 0) { // condition.
        printf("%d\n", i);
        i--; // decrement.
    }
}