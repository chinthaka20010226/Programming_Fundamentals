#include <stdio.h>

int main() {
    int i = 1; // initialization.
    while(i < 10) { // condition.
        printf("%d\n", i);
        i += 2; // increment by 2;
    }
}